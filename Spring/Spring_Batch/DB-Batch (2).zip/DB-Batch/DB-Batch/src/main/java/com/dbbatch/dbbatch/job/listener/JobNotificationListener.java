package com.dbbatch.dbbatch.job.listener;

import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Slf4j
@Component
public class JobNotificationListener implements JobExecutionListener {

    @Override
    public void beforeJob(JobExecution jobExecution){
        log.info("\n \n \n ++++++++++++++[ " + jobExecution.getJobInstance().getJobName() + " ]" + "start : { " +
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss")) + " }");
   }


   @Override
   public void afterJob(JobExecution jobExecution){
        if(jobExecution.getStatus().equals(BatchStatus.FAILED)){
            log.error("\n { " + jobExecution.getJobInstance().getJobName() + " }-batch-fail  |  start-time : { " +
                    jobExecution.getStartTime() + " }  | end-time : { " + jobExecution.getEndTime() + " } |  exception : { " + jobExecution.getExitStatus().getExitDescription() +" }");
        }
       log.info("\n ++++++++++++++[ " + jobExecution.getJobInstance().getJobName() + " ]" + "start : { " +
               LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss")) + " }");
   }
}



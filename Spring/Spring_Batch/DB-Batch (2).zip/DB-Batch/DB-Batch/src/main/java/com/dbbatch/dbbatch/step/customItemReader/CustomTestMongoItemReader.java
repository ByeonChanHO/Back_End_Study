package com.dbbatch.dbbatch.step.customItemReader;

import com.dbbatch.dbbatch.model.DiagInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.*;

import java.util.List;

@Slf4j
public class CustomTestMongoItemReader implements ItemStreamReader<DiagInfo> {
    private final List<DiagInfo> items;
    private int index;
    private boolean restart = false; // 재시작 여부

    public CustomTestMongoItemReader(List<DiagInfo> items) {
        this.items = items;
        this.index = 0;
    }

    @Override
    public void open(ExecutionContext executionContext) throws ItemStreamException {

        if (executionContext.containsKey("index")) { // index 키 데이터가 DB에 저장되어있다는 얘기
            index = executionContext.getInt("index");
            this.restart = true; // 재시작 가능으로 변경
        } else {
            index = 0;
            executionContext.put("index", index);
        }


        ItemStreamReader.super.open(executionContext);
    }

    @Override
    public void update(ExecutionContext executionContext) throws ItemStreamException {

        log.info("CustomMongoItemStreamReader.update");
        executionContext.put("index", index);

        ItemStreamReader.super.update(executionContext);
    }

    @Override
    public void close() throws ItemStreamException {

        log.info("CustomMongoItemStreamReader.close");
        ItemStreamReader.super.close();
    }

    @Override
    public DiagInfo read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
//        log.info("CustomItemStreamReader.read");
        DiagInfo item = null;

        if (this.index < this.items.size()) {
            item = this.items.get(index);
            index++; // index 1씩 증가
        }

//        if (this.index == 6 && !restart) { // 고의 실패 (재시작이 아닐 경우에만)
//            throw new RuntimeException("Restart is required");
//        }

        return item;
    }
}

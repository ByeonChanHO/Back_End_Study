package com.dbbatch.dbbatch.job;


import com.dbbatch.dbbatch.job.listener.JobNotificationListener;
import com.dbbatch.dbbatch.model.DiagInfo;
import com.dbbatch.dbbatch.step.DeleteDiagnosisInfoStepTask;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@RequiredArgsConstructor
@Slf4j
public class DiagnosisInfoJob {

    private final JobRepository jobRepository;
    private final JobNotificationListener jobNotificationListener;

    private final DeleteDiagnosisInfoStepTask deleteDiagnosisInfoStepTask;


    private final PlatformTransactionManager transactionManager;


    @Bean(name = "DiagInfoDataDeleteJob")
    public Job diagInfoDataDeleteJob(){

        JobBuilder builder = new JobBuilder("DiagInfoDataDeleteJob").repository(jobRepository);

        return builder.start(diagInfoDataDeleteStep(null, null))
                .listener(jobNotificationListener)
                .incrementer(new RunIdIncrementer())
                .build();
    }

    @Bean(name = "DiagInfoDataDeleteStep")
    @JobScope
    public Step diagInfoDataDeleteStep(@Value("#{jobParameters[fromDate]}") String fromDate, @Value("#{jobParameters[toDate]}") String toDate){
        log.info(">>>>>>>>>>>>>> Start Step is diafInfoDataDeleteStep");

        StepBuilder builder = new StepBuilder("DiagInfoDataArrangeStep").repository(jobRepository);



        return builder.<DiagInfo, DiagInfo>chunk(5000)
                .transactionManager(transactionManager)
                .reader(deleteDiagnosisInfoStepTask.CustomDelReader(fromDate,toDate))
                .processor(deleteDiagnosisInfoStepTask.delProcess())
                .writer(deleteDiagnosisInfoStepTask.upsertDiagInfoWriter())
                .build();
    }



}

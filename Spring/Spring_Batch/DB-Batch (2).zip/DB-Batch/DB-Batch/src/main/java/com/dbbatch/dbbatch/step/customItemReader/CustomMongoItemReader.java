package com.dbbatch.dbbatch.step.customItemReader;


import lombok.extern.slf4j.Slf4j;
import org.bson.Document;
import org.bson.codecs.DecoderContext;
import org.springframework.batch.item.ItemCountAware;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.data.AbstractPaginatedDataItemReader;
import org.springframework.batch.item.data.MongoItemReader;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.util.json.ParameterBindingDocumentCodec;
import org.springframework.data.mongodb.util.json.ParameterBindingJsonReader;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.util.ClassUtils;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@Slf4j
public class CustomMongoItemReader<T> extends AbstractPaginatedDataItemReader<T> implements InitializingBean{


    private MongoOperations template;

    private Query query;

    private String queryString;

    private Class<? extends T> type;

    private Sort sort;

    private String hint;

    private String fields;

    private String collection;

    private List<Object> parameterValues = new ArrayList<>();

    private int maxItemCount = Integer.MAX_VALUE;

    private Object lock = new Object();

    private T beforItem;

    public CustomMongoItemReader() {
        super();
        setName(ClassUtils.getShortName(CustomMongoItemReader.class));
    }

    /**
     * A Mongo Query to be used.
     * @param query Mongo Query to be used.
     */
    public void setQuery(Query query) {
        this.query = query;
    }

    /**
     * Used to perform operations against the MongoDB instance. Also handles the mapping
     * of documents to objects.
     * @param template the MongoOperations instance to use
     * @see org.springframework.data.mongodb.core.MongoOperations
     */
    public void setTemplate(MongoOperations template) {
        this.template = template;
    }

    /**
     * A JSON formatted MongoDB query. Parameterization of the provided query is allowed
     * via ?&lt;index&gt; placeholders where the &lt;index&gt; indicates the index of the
     * parameterValue to substitute.
     * @param queryString JSON formatted Mongo query
     */
    public void setQuery(String queryString) {
        this.queryString = queryString;
    }

    /**
     * The type of object to be returned for each {@link #read()} call.
     * @param type the type of object to return
     */
    public void setTargetType(Class<? extends T> type) {
        this.type = type;
    }

    /**
     * {@link List} of values to be substituted in for each of the parameters in the
     * query.
     * @param parameterValues values
     */
    public void setParameterValues(List<Object> parameterValues) {
        Assert.notNull(parameterValues, "Parameter values must not be null");
        this.parameterValues = parameterValues;
    }

    /**
     * JSON defining the fields to be returned from the matching documents by MongoDB.
     * @param fields JSON string that identifies the fields to sort by.
     */
    public void setFields(String fields) {
        this.fields = fields;
    }

    /**
     * {@link Map} of property
     * names/{@link org.springframework.data.domain.Sort.Direction} values to sort the
     * input by.
     * @param sorts map of properties and direction to sort each.
     */
    public void setSort(Map<String, Sort.Direction> sorts) {
        Assert.notNull(sorts, "Sorts must not be null");
        this.sort = convertToSort(sorts);
    }

    /**
     * @param collection Mongo collection to be queried.
     */
    public void setCollection(String collection) {
        this.collection = collection;
    }

    /**
     * JSON String telling MongoDB what index to use.
     * @param hint string indicating what index to use.
     */
    public void setHint(String hint) {
        this.hint = hint;
    }

    public void setMaxItemCount(int maxItemCount){
        this.maxItemCount = maxItemCount;
        super.setMaxItemCount(maxItemCount);
    }

    @Override
    @SuppressWarnings("unchecked")
    protected Iterator<T> doPageRead() {
        if (queryString != null) {
            Pageable pageRequest = PageRequest.of(page, pageSize, sort);

            String populatedQuery = replacePlaceholders(queryString, parameterValues);

            Query mongoQuery;

            if (StringUtils.hasText(fields)) {
                mongoQuery = new BasicQuery(populatedQuery, fields);
            }
            else {
                mongoQuery = new BasicQuery(populatedQuery);
            }

            mongoQuery.with(pageRequest);

            if (StringUtils.hasText(hint)) {
                mongoQuery.withHint(hint);
            }

            if (StringUtils.hasText(collection)) {
                return (Iterator<T>) template.find(mongoQuery, type, collection).iterator();
            }
            else {
                return (Iterator<T>) template.find(mongoQuery, type).iterator();
            }

        }
        else {
            Pageable pageRequest = PageRequest.of(0, pageSize);
            query.with(pageRequest);


            if (StringUtils.hasText(collection)) {
                return (Iterator<T>) template.find(query, type, collection).iterator();
            }
            else {
                return (Iterator<T>) template.find(query, type).iterator();

            }
        }
    }

    @Nullable
    @Override
    protected T doRead() throws Exception {

        synchronized (lock) {
            if (results == null || !results.hasNext()) {

                results = doPageRead();

                page++;

                if (results == null || !results.hasNext()) {
                    return null;
                }
            }

            if (results.hasNext()) {
                return results.next();
            }
            else {
                return null;
            }
        }
    }


    @Nullable
    @Override
    public T read() throws Exception, UnexpectedInputException, ParseException {
        if (super.getCurrentItemCount() >= maxItemCount) {
            return null;
        }
        super.setCurrentItemCount(super.getCurrentItemCount() +1);
        T item = doRead();

        if(super.getCurrentItemCount() % pageSize == 1) {
            if( beforItem == null || (item !=null && !beforItem.toString().equals(item.toString())) ){
                beforItem = item;
            } else if (item != null && beforItem.toString().equals(item.toString())) {
                return null;
            }
        }

        if (item instanceof ItemCountAware) {
            ((ItemCountAware) item).setItemCount(super.getCurrentItemCount());
        }
        return item;
    }


    /**
     * Checks mandatory properties
     *
     * @see InitializingBean#afterPropertiesSet()
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        Assert.state(template != null, "An implementation of MongoOperations is required.");
        Assert.state(type != null, "A type to convert the input into is required.");
        Assert.state(queryString != null || query != null, "A query is required.");

        if (queryString != null) {
            Assert.state(sort != null, "A sort is required.");
        }
    }

    private String replacePlaceholders(String input, List<Object> values) {
        ParameterBindingJsonReader reader = new ParameterBindingJsonReader(input, values.toArray());
        DecoderContext decoderContext = DecoderContext.builder().build();
        Document document = new ParameterBindingDocumentCodec().decode(reader, decoderContext);
        return document.toJson();
    }

    private Sort convertToSort(Map<String, Sort.Direction> sorts) {
        List<Sort.Order> sortValues = new ArrayList<>(sorts.size());

        for (Map.Entry<String, Sort.Direction> curSort : sorts.entrySet()) {
            sortValues.add(new Sort.Order(curSort.getValue(), curSort.getKey()));
        }

        return Sort.by(sortValues);
    }
}

package com.dbbatch.dbbatch;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.*;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Map;


@RequiredArgsConstructor
@Slf4j
@Controller
public class BatchController {

    private final JobLauncher jobLauncher;

    private final Job job;

    @GetMapping("batch")
    public ResponseEntity launcher(@RequestBody Map<String, String> body){

        try {

            JobParameters jobParameter = new JobParametersBuilder()
                    .addString("fromDate", body.get("fromDate"))
                    .addString("toDate", body.get("toDate"))
                    .toJobParameters();

            jobLauncher.run(job, jobParameter);

        } catch (JobExecutionAlreadyRunningException e) {
            throw new RuntimeException(e);
        } catch (JobRestartException e) {
            throw new RuntimeException(e);
        } catch (JobInstanceAlreadyCompleteException e) {
            throw new RuntimeException(e);
        } catch (JobParametersInvalidException e) {
            throw new RuntimeException(e);
        }

        return new ResponseEntity<>("scucces", HttpStatus.OK);
    }

}

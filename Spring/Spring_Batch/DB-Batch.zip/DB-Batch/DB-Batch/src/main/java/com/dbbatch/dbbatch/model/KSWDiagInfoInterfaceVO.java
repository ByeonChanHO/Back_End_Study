package com.dbbatch.dbbatch.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
public class KSWDiagInfoInterfaceVO {

    private String vin;
    private String dgnSn;
    private String dgnDtlS;
    private String dgnYmd;
    private String dgnCtms;
    private String ecuId;
    private String bkdwCd;
    private String occuYmd;
    private String occuCtms;
    private String occuTrvgDist;
    private String ecuIdNm;
    private String bkdwAfiExplSbc;

}

package com.dbbatch.dbbatch.step;

import com.dbbatch.dbbatch.model.*;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.data.MongoItemReader;
import org.springframework.batch.item.data.builder.MongoItemReaderBuilder;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Component
@Slf4j
@RequiredArgsConstructor
public class KSWDiagnosisInfoStepTask {

    @Autowired
    private MongoOperations mongoOperations;
    @Autowired
    @Qualifier("dataSource")
    private DataSource dataSource;

    @Value("${query.ksw-if-insert}")
    private String ifInsertQuery;

    @Bean
    public MongoItemReader<DiagInfo> kswReader(){
        LocalDateTime localDateTime = LocalDateTime.now();

        //1시간 마다
        String fromDate = localDateTime.getYear() + "/" + String.format("%02d",localDateTime.getMonthValue()) + "/" + String.format("%02d",localDateTime.getDayOfMonth()) + " "
                + String.format("%02d",localDateTime.getHour()) +":00:00";
        String toDate = localDateTime.plusHours(1).getYear() + "/" + String.format("%02d", localDateTime.plusHours(1).getMonthValue()) + "/" + String.format("%02d", localDateTime.plusHours(1).getDayOfMonth()) + " "
                + String.format("%02d",localDateTime.plusHours(1).getHour()) + ":59:59";

        Query query = new Query(new Criteria().andOperator(Criteria.where("createDate").gte(fromDate).lte(toDate), Criteria.where("bodyInfo").regex(".*\"milStatus\":1.*"), Criteria.where("vin").regex("KN")));

        log.info("[KSW Reader] Query {}", query);

        return new MongoItemReaderBuilder<DiagInfo>()
                .name("KSW Reader")
                .collection("DiagInfo")
                .template(mongoOperations)
                .targetType(DiagInfo.class)
                .query(query)
                .sorts(Map.of("vin", Sort.Direction.ASC))
                .pageSize(5000)
                .build();


    }

    @Bean
    public ItemProcessor<DiagInfo, List<MapSqlParameterSource>> kswProcess(){
        return diagInfo->{


            JsonParser parser = new JsonParser();

            //(diagInfo.getBodyInfo() != null) bodyInfo 가 없는 경우은 생각 X 이미 조회에서 있는 걸 가져옴
            JsonObject bodyInfo = (JsonObject) parser.parse(diagInfo.getBodyInfo());
            JsonArray dtcInfo = bodyInfo.getAsJsonArray("dtcInfo");
            JsonArray codeList = dtcInfo.get(0).getAsJsonObject().getAsJsonArray("codeList");
            //TODO : DB가 확인 안되니 Batch 에서 한 그래로 unit 계산 안하고 odometer value 를 그냥 보내겠다
            Double odometerValue = dtcInfo.get(0).getAsJsonObject().getAsJsonObject("odometer").get("value").getAsDouble();
            int odometerUnit = dtcInfo.get(0).getAsJsonObject().getAsJsonObject("odometer").get("unit").getAsInt();
            LocalDateTime time;




            if(dtcInfo.get(0).getAsJsonObject().has("time")){
                time = LocalDateTime.parse(dtcInfo.get(0).getAsJsonObject().getAsJsonObject("time").get("utc").getAsString(), DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
            } else {
                time = null;
            }

            String fuelType = diagInfo.getHeader().get("fueltype");

            List<MapSqlParameterSource> kswDiagInfoInterfaceVOList = new ArrayList<>();

            codeList.forEach(element -> {

                JsonObject breakDownCode = element.getAsJsonObject();

                if(breakDownCode.has("milStatus") && breakDownCode.get("milStatus").getAsInt() == 1){
                    Criteria criteria = new Criteria().andOperator(
                            Criteria.where("ecuID").is(breakDownCode.get("ecuID").getAsString()),
                            Criteria.where("fuelType").is(fuelType),
                            Criteria.where("language").is(3));

                    Query query = new Query(criteria);


                    //만약 데이터가 없을 경우, null로 들어옴.
                    BreakdownStatement breakdownStatement = mongoOperations.findOne(query, BreakdownStatement.class);

                    if(breakdownStatement != null){
                        LocalDateTime createDate = LocalDateTime.parse(diagInfo.getCreateDate(), DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss"));
                        LocalDateTime now = LocalDateTime.now();

                        String bkdwCd = DiagUnitEnum.valueOf("UNIT"+breakDownCode.get("dtcCode").getAsString().substring(0,1).toUpperCase()).unit + breakDownCode.get("dtcCode").getAsString().substring(1);


                        MapSqlParameterSource kswDiagInfoInterfaceVO = new MapSqlParameterSource();
                        kswDiagInfoInterfaceVO.addValue("vin", diagInfo.getVin());
                        kswDiagInfoInterfaceVO.addValue("dgnSn", now.format(DateTimeFormatter.ofPattern("HHmmssSSS")));
                        kswDiagInfoInterfaceVO.addValue("dgnDtlSn", now.format(DateTimeFormatter.ofPattern("HHmmss")) + (Math.round(Math.random() * 1000)));
                        kswDiagInfoInterfaceVO.addValue("dgnYmd", createDate.format(DateTimeFormatter.ofPattern("yyyyMMdd")));
                        kswDiagInfoInterfaceVO.addValue("dgnCtms", createDate.format(DateTimeFormatter.ofPattern("HHmmss")));
                        kswDiagInfoInterfaceVO.addValue("ecuId", breakDownCode.get("ecuID").getAsString());
                        kswDiagInfoInterfaceVO.addValue("bkdwCd", bkdwCd);
                        kswDiagInfoInterfaceVO.addValue("occuYmd", time.format(DateTimeFormatter.ofPattern("yyyyMMdd")));
                        kswDiagInfoInterfaceVO.addValue("occuCtms", time.format(DateTimeFormatter.ofPattern("HHmmss")));
                        kswDiagInfoInterfaceVO.addValue("occuTrvgDist", odometerValue.toString());
                        kswDiagInfoInterfaceVO.addValue("ecuIdNm", breakdownStatement.getEcuIDName());
                        kswDiagInfoInterfaceVO.addValue("bkdwAfiExplSbc", breakdownStatement.getMessage());


                        kswDiagInfoInterfaceVOList.add(kswDiagInfoInterfaceVO);

                    }


                }

                log.info("[KSW Processor] DiagInfo Data : {} | 고장 내역 : {}", diagInfo, kswDiagInfoInterfaceVOList);

            });

            return kswDiagInfoInterfaceVOList;

        };
    }

    @Bean
    public ItemWriter<List<MapSqlParameterSource>> kswWriter() {
        return diagInfoInterfaceVOs -> {


            NamedParameterJdbcTemplate jdbcTemplate = new NamedParameterJdbcTemplate(dataSource);


            for (List<MapSqlParameterSource> kswDiagInfoInterfaceVOList : diagInfoInterfaceVOs) {
                for (MapSqlParameterSource kswDiagInfoInterfaceVO : kswDiagInfoInterfaceVOList) {


                    jdbcTemplate.update(ifInsertQuery, kswDiagInfoInterfaceVO);
                }
            }

        };
    }

    @Bean
    public ItemWriter<List<MapSqlParameterSource>> kswWriterSampling(){
        return diagInfoInterfaceVOs ->{

            for (List<MapSqlParameterSource> kswDiagInfoInterfaceVOList : diagInfoInterfaceVOs) {
                for (MapSqlParameterSource kswDiagInfoInterfaceVO : kswDiagInfoInterfaceVOList) {

                    mongoOperations.insert(kswDiagInfoInterfaceVO,"KswDiagSampling");

                }
            }


        };
    }


}

package com.dbbatch.dbbatch;

import com.dbbatch.dbbatch.config.BatchConfiguration;
import com.dbbatch.dbbatch.job.DiagnosisInfoJob;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.*;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.task.TaskExecutor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Map;


@RequiredArgsConstructor
@Slf4j
@Controller
public class BatchController {

    private final JobLauncher jobLauncher;

//    private final Job job;
//
    @Autowired
    private DiagnosisInfoJob diagnosisInfoJob;

    @GetMapping("batch")
    public ResponseEntity launcher(@RequestBody Map<String, String> body){

        try {

//            JobParameters jobParameter = new JobParametersBuilder()
//                    .addString("fromDate", body.get("fromDate"))
//                    .addString("toDate", body.get("toDate"))
//                    .toJobParameters();

            JobParameters jobParameter = new JobParametersBuilder()
                    .addString("checkTest", body.get("checkTest"))
                    .toJobParameters();

            jobLauncher.run(diagnosisInfoJob.diagInfoDataDeleteJob(), jobParameter);

        } catch (JobExecutionAlreadyRunningException e) {
            throw new RuntimeException(e);
        } catch (JobRestartException e) {
            throw new RuntimeException(e);
        } catch (JobInstanceAlreadyCompleteException e) {
            throw new RuntimeException(e);
        } catch (JobParametersInvalidException e) {
            throw new RuntimeException(e);
        }

        return new ResponseEntity<>("scucces", HttpStatus.OK);
    }


    @GetMapping("CRM")
    public ResponseEntity CRMlauncher(@RequestBody Map<String, String> body){


        try {

//            JobParameters jobParameter = new JobParametersBuilder()
//                    .addString("fromDate", body.get("fromDate"))
//                    .addString("toDate", body.get("toDate"))
//                    .toJobParameters();

            JobParameters jobParameter = new JobParametersBuilder()
                    .toJobParameters();

            jobLauncher.run(diagnosisInfoJob.crmDiagnosisJob(), jobParameter);

        } catch (JobExecutionAlreadyRunningException e) {
            throw new RuntimeException(e);
        } catch (JobRestartException e) {
            throw new RuntimeException(e);
        } catch (JobInstanceAlreadyCompleteException e) {
            throw new RuntimeException(e);
        } catch (JobParametersInvalidException e) {
            throw new RuntimeException(e);
        }

        return new ResponseEntity<>("scucces", HttpStatus.OK);
    }


    @GetMapping("HSW")
    public ResponseEntity HSWlauncher(@RequestBody Map<String, String> body){


        try {

//            JobParameters jobParameter = new JobParametersBuilder()
//                    .addString("fromDate", body.get("fromDate"))
//                    .addString("toDate", body.get("toDate"))
//                    .toJobParameters();

            JobParameters jobParameter = new JobParametersBuilder()
                    .toJobParameters();

            jobLauncher.run(diagnosisInfoJob.hswDiagnosisJob(), jobParameter);

        } catch (JobExecutionAlreadyRunningException e) {
            throw new RuntimeException(e);
        } catch (JobRestartException e) {
            throw new RuntimeException(e);
        } catch (JobInstanceAlreadyCompleteException e) {
            throw new RuntimeException(e);
        } catch (JobParametersInvalidException e) {
            throw new RuntimeException(e);
        }

        return new ResponseEntity<>("scucces", HttpStatus.OK);
    }


    @GetMapping("KSW")
    public ResponseEntity KSWlauncher(@RequestBody Map<String, String> body){


        try {

//            JobParameters jobParameter = new JobParametersBuilder()
//                    .addString("fromDate", body.get("fromDate"))
//                    .addString("toDate", body.get("toDate"))
//                    .toJobParameters();

            JobParameters jobParameter = new JobParametersBuilder()
                    .toJobParameters();

            jobLauncher.run(diagnosisInfoJob.kswDiagnosisJob(), jobParameter);

        } catch (JobExecutionAlreadyRunningException e) {
            throw new RuntimeException(e);
        } catch (JobRestartException e) {
            throw new RuntimeException(e);
        } catch (JobInstanceAlreadyCompleteException e) {
            throw new RuntimeException(e);
        } catch (JobParametersInvalidException e) {
            throw new RuntimeException(e);
        }

        return new ResponseEntity<>("scucces", HttpStatus.OK);
    }



    @GetMapping("CRMDriv")
    public ResponseEntity CRMDriveLauncher(@RequestBody Map<String, String> body){


        try {

//            JobParameters jobParameter = new JobParametersBuilder()
//                    .addString("fromDate", body.get("fromDate"))
//                    .addString("toDate", body.get("toDate"))
//                    .toJobParameters();

            JobParameters jobParameter = new JobParametersBuilder()
                    .toJobParameters();

            jobLauncher.run(diagnosisInfoJob.crmDriveJob(), jobParameter);

        } catch (JobExecutionAlreadyRunningException e) {
            throw new RuntimeException(e);
        } catch (JobRestartException e) {
            throw new RuntimeException(e);
        } catch (JobInstanceAlreadyCompleteException e) {
            throw new RuntimeException(e);
        } catch (JobParametersInvalidException e) {
            throw new RuntimeException(e);
        }

        return new ResponseEntity<>("scucces", HttpStatus.OK);
    }
}

package com.dbbatch.dbbatch.job;


import com.dbbatch.dbbatch.config.BatchConfiguration;
import com.dbbatch.dbbatch.job.listener.JobNotificationListener;
import com.dbbatch.dbbatch.model.*;
import com.dbbatch.dbbatch.step.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.transaction.PlatformTransactionManager;

import java.util.List;

@Configuration
@RequiredArgsConstructor
@Slf4j
public class DiagnosisInfoJob {

    private final JobRepository jobRepository;
    private final JobNotificationListener jobNotificationListener;

    private final DeleteDiagnosisInfoStepTask deleteDiagnosisInfoStepTask;

    private final CrmDiagnosisInfoStepTask crmDiagnosisInfoStepTask;

    private final HSWDiagnosisInfoStepTask hswDiagnosisInfoStepTask;

    private final KSWDiagnosisInfoStepTask kswDiagnosisInfoStepTask;

    private final CrmDriveInfoMngrTask crmDriveInfoMngrTask;


    private final PlatformTransactionManager transactionManager;

    private final BatchConfiguration batchConfiguration;

    @Value("${spring.async.chunk-size}")
    private String chunkSize;


    @Bean(name = "DiagInfoDataDeleteJob")
    public Job diagInfoDataDeleteJob(){

        JobBuilder builder = new JobBuilder("DiagInfoDataDeleteJob").repository(jobRepository);

        return builder.start(diagInfoDataDeleteStep(null))
                .listener(jobNotificationListener)
                .incrementer(new RunIdIncrementer())
                .build();
    }


    @Bean(name = "DiagInfoDataDeleteStep")
    @JobScope
    public Step diagInfoDataDeleteStep(@Value("#{jobParameters[checkTest]}") String checkTest){
        log.info(">>>>>>>>>>>>>> Start Step is diafInfoDataDeleteStep");

        StepBuilder builder = new StepBuilder("DiagInfoDataArrangeStep").repository(jobRepository);




        return builder.<DiagInfo, DiagInfo>chunk(Integer.parseInt(chunkSize))
                .transactionManager(transactionManager)
                .reader(deleteDiagnosisInfoStepTask.CustomDelReader(checkTest))
                .writer(deleteDiagnosisInfoStepTask.delDiagInfoWriter())
                .taskExecutor(batchConfiguration.taskExecutor())
                .build();
    }

    @Bean(name = "CrmDiagnosisJob")
    public Job crmDiagnosisJob(){

        JobBuilder builder = new JobBuilder("CrmDiagnosisJob").repository(jobRepository);

        return builder.start(crmDiagnosisStep())
                .listener(jobNotificationListener)
                .incrementer(new RunIdIncrementer())
                .build();
    }

    @Bean(name = "CrmDiagnosisStep")
    public Step crmDiagnosisStep(){
        log.info(">>>>>>>>>>>>>> Start Step is CrmDiagnosisStep");

        StepBuilder builder = new StepBuilder("CrmDiagnosisStep").repository(jobRepository);


        return builder.<CrmDiagInfo, CrmInterfaceVO>chunk(Integer.parseInt(chunkSize))
                .transactionManager(transactionManager)
                .reader(crmDiagnosisInfoStepTask.crmReader())
                .processor(crmDiagnosisInfoStepTask.crmProcess())
                .writer(crmDiagnosisInfoStepTask.crmWriter())
                .build();
    }


    @Bean(name = "HSWDiagnosisJob")
    public Job hswDiagnosisJob(){

        JobBuilder builder = new JobBuilder("HSWDiagnosisJob").repository(jobRepository);

        return builder.start(hswDiagnosisStep())
                .listener(jobNotificationListener)
                .incrementer(new RunIdIncrementer())
                .build();
    }

    @Bean(name = "HSWDiagnosisStep")
    public Step hswDiagnosisStep(){
        log.info(">>>>>>>>>>>>>> Start Step is HSWDiagnosisStep");

        StepBuilder builder = new StepBuilder("HSWDiagnosisStep").repository(jobRepository);


        return builder.<DiagInfo, HSWDiagInfoInterfaceVO>chunk(Integer.parseInt(chunkSize))
                .transactionManager(transactionManager)
                .reader(hswDiagnosisInfoStepTask.hswReader())
                .processor(hswDiagnosisInfoStepTask.hswProcess())
                .writer(hswDiagnosisInfoStepTask.hswWriter())
                .build();
    }


    @Bean(name = "KSWDiagnosisJob")
    public Job kswDiagnosisJob(){

        JobBuilder builder = new JobBuilder("KSWDiagnosisJob").repository(jobRepository);

        return builder.start(kswDiagnosisStep())
                .listener(jobNotificationListener)
                .incrementer(new RunIdIncrementer())
                .build();
    }

    @Bean(name = "KSWDiagnosisStep")
    public Step kswDiagnosisStep(){
        log.info(">>>>>>>>>>>>>> Start Step is KSWDiagnosisStep");

        StepBuilder builder = new StepBuilder("KSWDiagnosisStep").repository(jobRepository);


        return builder.<DiagInfo, List<MapSqlParameterSource>>chunk(Integer.parseInt(chunkSize))
                .transactionManager(transactionManager)
                .reader(kswDiagnosisInfoStepTask.kswReader())
                .processor(kswDiagnosisInfoStepTask.kswProcess())
                .writer(kswDiagnosisInfoStepTask.kswWriter())
                .build();
    }

    @Bean(name = "CrmDriveJob")
    public Job crmDriveJob(){

        JobBuilder builder = new JobBuilder("CrmDriveJob").repository(jobRepository);

        return builder.start(crmDriveStep())
                .listener(jobNotificationListener)
                .incrementer(new RunIdIncrementer())
                .build();
    }

    @Bean(name = "CrmDriveStep")
    public Step crmDriveStep(){
        log.info(">>>>>>>>>>>>>> Start Step is crmDriveStep");

        StepBuilder builder = new StepBuilder("CrmDriveStep").repository(jobRepository);


        return builder.<CrmOdometer, CrmInterfaceVO_Driv>chunk(Integer.parseInt(chunkSize))
                .transactionManager(transactionManager)
                .reader(crmDriveInfoMngrTask.crmDriveReader())
                .processor(crmDriveInfoMngrTask.crmDriveProcessor())
                .writer(crmDriveInfoMngrTask.crmDriveWriter())
                .build();
    }




}

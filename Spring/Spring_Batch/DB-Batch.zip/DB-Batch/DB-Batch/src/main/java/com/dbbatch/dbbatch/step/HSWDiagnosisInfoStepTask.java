package com.dbbatch.dbbatch.step;

import com.dbbatch.dbbatch.model.DiagInfo;
import com.dbbatch.dbbatch.model.HSWDiagInfoInterfaceVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.data.MongoItemReader;
import org.springframework.batch.item.data.builder.MongoItemReaderBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

@Component
@Slf4j
@RequiredArgsConstructor
public class HSWDiagnosisInfoStepTask {

    @Autowired
    private MongoOperations mongoOperations;
    @Autowired
    @Qualifier("dataSource")
    private DataSource dataSource;

    @Value("${query.hsw-if-insert}")
    private String ifInsertQuery;

    @Value("${query.hsw-if-exists}")
    private String ifExistsQuery;

    @Bean
    public MongoItemReader<DiagInfo> hswReader(){
        LocalDateTime localDateTime = LocalDateTime.now();

        //다음 날 새벽일 경우를 위해 toDate 도 minus 1일 할꺼임
        String fromDate = localDateTime.minusDays(2).getYear() + "/" + String.format("%02d",localDateTime.minusDays(2).getMonthValue()) + "/" + String.format("%02d",localDateTime.minusDays(2).getDayOfMonth()) + " 00:00:00";
        String toDate = localDateTime.minusDays(1).getYear() + "/" + String.format("%02d", localDateTime.minusDays(1).getMonthValue()) + "/" + String.format("%02d", localDateTime.minusDays(1).getDayOfMonth()) + " 23:59:59";

        Query query = new Query(new Criteria().andOperator(Criteria.where("createDate").gte(fromDate).lte(toDate), Criteria.where("bodyInfo").regex(".*\"milStatus\":1.*"), Criteria.where("vin").regex("KM")));

        log.info("[HSW Reader] Query {}", query);

        return new MongoItemReaderBuilder<DiagInfo>()
                .name("HSW Reader")
                .collection("DiagInfo")
                .template(mongoOperations)
                .targetType(DiagInfo.class)
                .query(query)
                .sorts(Map.of("vin", Sort.Direction.ASC))
                .pageSize(5000)
                .build();


    }

    @Bean
    public ItemProcessor<DiagInfo, HSWDiagInfoInterfaceVO> hswProcess(){
        return diagInfo->{
          LocalDateTime createDate = LocalDateTime.parse(diagInfo.getCreateDate(), DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss"));
          LocalDateTime now = LocalDateTime.now();

          HSWDiagInfoInterfaceVO hswDiagInfoInterfaceVO = HSWDiagInfoInterfaceVO.builder()
                  .vin(diagInfo.getVin())
                  .dgnYmd(createDate.format(DateTimeFormatter.ofPattern("yyyyMMdd")))
                  .creDtm(now.format(DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss")))
                  .finMdfyDtm(now.format(DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss")))
                  .dgnCtms(createDate.format(DateTimeFormatter.ofPattern("HHmmss")))
                  .build();

          return hswDiagInfoInterfaceVO;

        };
    }

    @Bean
    public ItemWriter<HSWDiagInfoInterfaceVO> hswWriter(){
        return diagInfoInterfaceVOs ->{

            NamedParameterJdbcTemplate jdbcTemplate = new NamedParameterJdbcTemplate(dataSource);

            for(HSWDiagInfoInterfaceVO diagInfoInterfaceVO : diagInfoInterfaceVOs){
                MapSqlParameterSource parameters = new MapSqlParameterSource();
                parameters.addValue("vin", diagInfoInterfaceVO.getVin());
                parameters.addValue("dgnYmd", diagInfoInterfaceVO.getDgnYmd());
                parameters.addValue("dgnCtms", diagInfoInterfaceVO.getDgnCtms());

                String count = jdbcTemplate.queryForObject(ifExistsQuery, parameters, String.class);

                parameters.addValue("creDtm", diagInfoInterfaceVO.getCreDtm());
                parameters.addValue("finMdfyDtm",diagInfoInterfaceVO.getFinMdfyDtm());

                if(count.equals(BigInteger.ZERO.toString()) || count.equals(null)){
                    log.info("[HSW Writer] (Insert) {}", diagInfoInterfaceVO);
                    jdbcTemplate.update(ifInsertQuery, parameters);
                }else{
                    log.info("[HSW Writer] (SKIP) {}", diagInfoInterfaceVO);
                }

            }

        };
    }

    @Bean
    public ItemWriter<HSWDiagInfoInterfaceVO> hswWriterSampling(){
        return hswDiagInfoInterfaceVOs ->{


            for(HSWDiagInfoInterfaceVO diagInfoInterfaceVO : hswDiagInfoInterfaceVOs){
              long count = mongoOperations.count(new Query().addCriteria(new Criteria().andOperator(
                      Criteria.where("vin").is(diagInfoInterfaceVO.getVin()),
                      Criteria.where("dgnYmd").is(diagInfoInterfaceVO.getDgnYmd()),
                      Criteria.where("dgnCtms").is(diagInfoInterfaceVO.getDgnCtms()))),
                      "HswDiagSampling"
              );

              if(count < 1){
                  log.info("[HSW Writer Sampling] (Insert) {}", diagInfoInterfaceVO);
                  mongoOperations.save(diagInfoInterfaceVO, "HswDiagSampling");
              }else{
                  log.info("[HSW Writer Sampling] (SKIP) {}", diagInfoInterfaceVO);
              }
          }
        };
    }


}

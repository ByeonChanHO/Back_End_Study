package com.dbbatch.dbbatch.step;

import com.dbbatch.dbbatch.model.DiagInfo;
import com.dbbatch.dbbatch.step.UpdateCustomReader.UpdateCustomMongoItemReader;
import com.dbbatch.dbbatch.step.UpdateCustomReader.UpdateCustomMongoItemReaderBuilder;
import com.mongodb.bulk.BulkWriteResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.util.Pair;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Slf4j
@RequiredArgsConstructor
public class UpdateDiagnosisInfoStepTask {

    private final MongoOperations mongoOperations;

    public final String JSON_QUERY_FORMAT = "{createDate: {'$gte': '%s', '$lte': '%s'}}";

    public int totalCount = 0;

    public final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");

    @Bean
    @StepScope
    public UpdateCustomMongoItemReader<DiagInfo> CustomDelReader(@Value("#{jobParameters[fromDate]}") String fromDate, @Value("#{jobParameters[toDate]}") String toDate) {
        log.info(">>>>>>>>>>>>>>> Tist is del Task \n fromDate : " + fromDate + ", toDate : " + toDate);
        Query query = new Query();
        Criteria criteria = new Criteria();
        LocalDateTime targetDate = LocalDateTime.now();

        if(fromDate.equals("now") || toDate.equals("now")) {
            LocalDateTime searchDate = LocalDateTime.now().minusDays(1);
            String toyyyyMMdd = searchDate.getYear() + "/" + searchDate.getMonthValue() + "/" + searchDate.getDayOfMonth() + " 23:59:59";

            log.info("Search Date Time : {}", toyyyyMMdd);

            criteria.andOperator(Criteria.where("createDate").lte(toyyyyMMdd), Criteria.where("registerDate").exists(false));
            query.addCriteria(criteria).with(Sort.by(Sort.Direction.DESC,"createDate"));
            targetDate = LocalDateTime.parse(mongoOperations.findOne(query, DiagInfo.class, "Test001").getCreateDate(), formatter);

            String fromyyyyMMdd = targetDate.plusDays(1).getYear() + "/" + String.format("%02d",targetDate.plusDays(1).getMonthValue()) + "/" + String.format("%02d",targetDate.plusDays(1).getDayOfMonth()) + " 00:00:00";
            toyyyyMMdd = targetDate.plusDays(1).getYear() + "/" + String.format("%02d", targetDate.plusDays(1).getMonthValue()) + "/" + String.format("%02d", targetDate.plusDays(1).getDayOfMonth()) + " 23:59:59";

            query = new Query();
            criteria = new Criteria();
            criteria.andOperator(Criteria.where("createDate").gte(fromyyyyMMdd), Criteria.where("createDate").lte(toyyyyMMdd), Criteria.where("registerDate").exists(false));
            query.addCriteria(criteria);

            log.info("Revicing now Date: " + query);

        }
        else {

            String fromyyyyMMdd = fromDate.substring(0, 4) + "/" + fromDate.substring(4, 6) + "/" + fromDate.substring(6, 8) + " 00:00:00";
            String toyyyyMMdd = toDate.substring(0, 4) + "/" + toDate.substring(4, 6) + "/" + toDate.substring(6, 8) + " 23:59:59";


            criteria.andOperator(Criteria.where("createDate").gte(fromyyyyMMdd), Criteria.where("createDate").lte(toyyyyMMdd), Criteria.where("registerDate").exists(false));

            query.addCriteria(criteria);

            log.info( "Revicing set Date" + query);
        }




        return new UpdateCustomMongoItemReaderBuilder<DiagInfo>()
                .name("Delete Diag Info Data")
                .template(mongoOperations)
                .collection("Test001")
                .targetType(DiagInfo.class)
                .query(query)
                .targetDate(targetDate)
                .threadNum(10)
                .sorts(Map.of("createDate", Sort.Direction.ASC))
                .pageSize(5000)
                .build();

//        return null;

    }

    public ItemWriter<DiagInfo> upsertDiagInfoWriter(){

        return diagInfos ->{
            log.info(">>>>>>>>>>>>>>>>> This is upsert Write Start");
            totalCount += diagInfos.size();
            log.info("totalCount : " + totalCount);


            if(diagInfos.size() > 0){
                log.info("Delete Driving Count : " + diagInfos.size());
                Criteria criteria = new Criteria();
                Update update = new Update();
                List<Pair<Query,Update>> updateList = new ArrayList<>();


                for(DiagInfo delInfo : diagInfos){
                    Query query = new Query();

                    criteria.andOperator(Criteria.where("vin").is(delInfo.getVin()), Criteria.where("createDate").is(delInfo.getCreateDate()));
                    LocalDateTime parse = LocalDateTime.parse(delInfo.getCreateDate(), formatter);
                    Date date = java.sql.Timestamp.valueOf(parse);

                    update.set("registerDate", date);

                    query.addCriteria(new Criteria().andOperator(Criteria.where("vin").is(delInfo.getVin()), Criteria.where("createDate").is(delInfo.getCreateDate())));


                    updateList.add(Pair.of(query,update));


                }

                bulkUpdate(updateList);
                log.info("Write End");

            }
        };

    }

    private BulkWriteResult bulkUpdate(List<Pair<Query, Update>> updateList){

        if(updateList.size() > 0){
            BulkOperations bulkOperations = mongoOperations.bulkOps(BulkOperations.BulkMode.UNORDERED, DiagInfo.class);
            bulkOperations.updateMulti(updateList);
            return bulkOperations.execute();
        }

        return null;
    }
}

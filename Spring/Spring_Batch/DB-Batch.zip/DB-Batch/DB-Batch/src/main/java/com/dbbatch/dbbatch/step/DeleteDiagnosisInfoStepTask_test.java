package com.dbbatch.dbbatch.step;

import com.dbbatch.dbbatch.model.DiagInfo;
import com.dbbatch.dbbatch.step.DeleteCustomItemReader.CustomMongoItemReader;
import com.dbbatch.dbbatch.step.DeleteCustomItemReader.CustomMongoItemReaderBuilder;
import com.dbbatch.dbbatch.step.DeleteCustomItemReader.CustomTestMongoItemReader;
import com.mongodb.bulk.BulkWriteResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.data.MongoItemReader;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.util.Pair;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

//@Component
@Slf4j
@RequiredArgsConstructor
public class DeleteDiagnosisInfoStepTask_test {

    private final MongoOperations mongoTemplate;

    public final String JSON_QUERY_FORMAT = "{createDate: {'$gte': '%s', '$lte': '%s'}}";

    public int totalCount = 0;

    public final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");


//    private int count;


//    @Bean
//    @StepScope
    public MongoItemReader<DiagInfo> delReader(@Value("#{jobParameters[fromDate]}") String fromDate, @Value("#{jobParameters[toDate]}") String toDate){
        log.info(">>>>>>>>>>>>>>> Tist is del Task \n fromDate : " +  fromDate + ", toDate : " + toDate);

        String fromyyyyMMdd = fromDate.substring(0,4) + "/" + fromDate.substring(4,6) + "/" + fromDate.substring(6,8) + " 00:00:00";
        String toyyyyMMdd = toDate.substring(0,4) + "/" + toDate.substring(4,6) + "/" + toDate.substring(6,8) + " 23:59:59";

        Criteria criteria = new Criteria();
        criteria.andOperator(Criteria.where("createDate").gte(fromyyyyMMdd), Criteria.where("createDate").lte(toyyyyMMdd));
        Query query = new Query();
        query.addCriteria(criteria);

        log.info(query.toString());

        mongoTemplate.remove(query,"Test001" );

//        return new MongoItemReaderBuilder<DiagInfo>()
//                .name("Delete Diag Info Data")
//                .template(mongoTemplate)
//                .collection("Test001")
//                .targetType(DiagInfo.class)
//                .query(query)
//                .sorts(Map.of("createDate", Sort.Direction.ASC))
//                .pageSize(5000)
//                .build();

        return null;

    }

    @Bean
    @StepScope
    public CustomMongoItemReader<DiagInfo> CustomDelReader(@Value("#{jobParameters[fromDate]}") String fromDate, @Value("#{jobParameters[toDate]}") String toDate) {
        log.info(">>>>>>>>>>>>>>> Tist is del Task \n fromDate : " + fromDate + ", toDate : " + toDate);
        Query query = new Query();
        Criteria criteria = new Criteria();
        LocalDateTime nowTargetDate = LocalDateTime.now();

        if(fromDate.equals("now") || toDate.equals("now")) {
            LocalDateTime targetDateTime = LocalDateTime.now().minusYears(1).minusDays(1);
            log.info("target Date Time : " + targetDateTime);

            String toyyyyMMdd = targetDateTime.getYear() + "/" + targetDateTime.getMonthValue() + "/" + targetDateTime.getDayOfMonth() + " 23:59:59";


            query.addCriteria(Criteria.where("createDate").lte(toyyyyMMdd)).with(Sort.by(Sort.Direction.ASC,"createDate"));

            nowTargetDate = LocalDateTime.parse(mongoTemplate.findOne(query, DiagInfo.class, "Test001").getCreateDate(), formatter);

            String fromyyyyMMdd = nowTargetDate.getYear() + "/" + String.format("%02d",nowTargetDate.getMonthValue()) + "/" + String.format("%02d",nowTargetDate.getDayOfMonth()) + " 00:00:00";
            toyyyyMMdd = nowTargetDate.getYear() + "/" + String.format("%02d", nowTargetDate.getMonthValue()) + "/" + String.format("%02d", nowTargetDate.getDayOfMonth()) + " 23:59:59";

            query = new Query();
            criteria.andOperator(Criteria.where("createDate").gte(fromyyyyMMdd), Criteria.where("createDate").lte(toyyyyMMdd));
            query.addCriteria(criteria).with(Sort.by(Sort.Direction.ASC,"createDate"));

            log.info("Revicing now Date: " + query);

        }
        else {

            String fromyyyyMMdd = fromDate.substring(0, 4) + "/" + fromDate.substring(4, 6) + "/" + fromDate.substring(6, 8) + " 00:00:00";
            String toyyyyMMdd = toDate.substring(0, 4) + "/" + toDate.substring(4, 6) + "/" + toDate.substring(6, 8) + " 23:59:59";

            criteria.andOperator(Criteria.where("createDate").gte(fromyyyyMMdd), Criteria.where("createDate").lte(toyyyyMMdd));

            query.addCriteria(criteria).with(Sort.by(Sort.Direction.ASC,"createDate"));

            log.info( "Revicing set Date" + query);
        }




        return new CustomMongoItemReaderBuilder<DiagInfo>()
                .name("Delete Diag Info Data")
                .template(mongoTemplate)
                .collection("Test001")
                .targetType(DiagInfo.class)
                .query(query)
                .targetDate(nowTargetDate)
                .sorts(Map.of("createDate", Sort.Direction.ASC))
                .pageSize(5000)
                .build();

//        return null;

    }

//    @Bean
//    @StepScope
    public ItemReader<DiagInfo> CustomDelReader1(@Value("#{jobParameters[fromDate]}") String fromDate, @Value("#{jobParameters[toDate]}") String toDate) {
        log.info(">>>>>>>>>>>>>>> Tist is del Task \n fromDate : " +  fromDate + ", toDate : " + toDate);

        String fromyyyyMMdd = fromDate.substring(0,4) + "/" + fromDate.substring(4,6) + "/" + fromDate.substring(6,8) + " 00:00:00";
        String toyyyyMMdd = toDate.substring(0,4) + "/" + toDate.substring(4,6) + "/" + toDate.substring(6,8) + " 23:59:59";

        Criteria criteria = new Criteria();
        criteria.andOperator(Criteria.where("createDate").gte(fromyyyyMMdd), Criteria.where("createDate").lte(toyyyyMMdd));
        Query query = new Query();
        query.addCriteria(criteria);

        List<DiagInfo> items = mongoTemplate.find(query,DiagInfo.class, "Test001");

        return new CustomTestMongoItemReader(items);
    }


    public ItemProcessor<DiagInfo, DiagInfo> delProcess(){

        return new ItemProcessor<DiagInfo, DiagInfo>() {
            @Override
            public DiagInfo process(DiagInfo diagInfo) throws Exception {
                return diagInfo;
            }
        };
    }

//    @Bean
    public ItemWriter<DiagInfo> upsertDiagInfoWriter(){

        return diagInfos ->{
            log.info(">>>>>>>>>>>>>>>>> This is upsert Write Start");
            totalCount += diagInfos.size();
            log.info("totalCount : " + totalCount);


            if(diagInfos.size() > 0){
                log.info("Delete Driving Count : " + diagInfos.size());
                Criteria criteria = new Criteria();
                Update update = new Update();
                List<Pair<Query,Update>> updateList = new ArrayList<>();


                for(DiagInfo delInfo : diagInfos){
                    Query query = new Query();

                    criteria.andOperator(Criteria.where("vin").is(delInfo.getVin()), Criteria.where("createDate").is(delInfo.getCreateDate()));
                    LocalDateTime parse = LocalDateTime.parse(delInfo.getCreateDate(), formatter);
                    Date date = java.sql.Timestamp.valueOf(parse);

                    update.set("registerDate", date);

                    query.addCriteria(new Criteria().andOperator(Criteria.where("vin").is(delInfo.getVin()), Criteria.where("createDate").is(delInfo.getCreateDate())));


                    updateList.add(Pair.of(query,update));


                }

                bulkUpdate(updateList);
                log.info("Write End");

            }
        };

    }


//    @Bean
    public ItemWriter<DiagInfo> delDiagInfoWriter(){

        return diagInfos ->{

//            LocalDateTime dateTime = LocalDateTime.now();
//            int hourMin = (dateTime.getHour()*100) + dateTime.getDayOfMonth();
//
//            if( (1650 <= hourMin && hourMin < 1900 )|| hourMin >= 2350 || (hourMin >= 650 && hourMin < 900) ){
//                throw new IllegalStateException(hourMin + " 시간대로 인해 종료");
//            }else{
//                bulkRemove(diagInfos);
//            }

            bulkRemove(diagInfos);

        };
    }


//    @Async
    public BulkWriteResult bulkRemove(Chunk<? extends DiagInfo> diagInfos) {
        log.info(">>>>>>>>>>>>>>>>> This is del Write Start");


        List<Query> removeList = new ArrayList<>();
        if(diagInfos.size() > 0) {
            log.info("Delete Driving Count : " + diagInfos.size());
            totalCount += diagInfos.size();
            log.info("totalCount : " + totalCount);

            log.info("createDate : {}", diagInfos.getItems().get(0).getCreateDate());


            for (DiagInfo delInfo : diagInfos) {
                Query query = new Query();
                Criteria first = Criteria.where("vin").is(delInfo.getVin());
                Criteria second = Criteria.where("createDate").is(delInfo.getCreateDate());
                query.addCriteria(new Criteria().andOperator(first, second));

                removeList.add(query);
            }
        }


        log.info("BulkRemove Start !!");
        log.info("Start Range : " + removeList.get(0));
        log.info("End Range : " + removeList.get(removeList.size() -1));


        if(removeList.size() > 0){
            BulkOperations bulkOperations = mongoTemplate.bulkOps(BulkOperations.BulkMode.UNORDERED, DiagInfo.class);
            bulkOperations.remove(removeList);
            return bulkOperations.execute();
        }

        return null;
    }

    private BulkWriteResult bulkUpdate(List<Pair<Query, Update>> updateList){

        if(updateList.size() > 0){
            BulkOperations bulkOperations = mongoTemplate.bulkOps(BulkOperations.BulkMode.UNORDERED, DiagInfo.class);
            bulkOperations.updateMulti(updateList);
            return bulkOperations.execute();
        }

        return null;
    }

}

package com.dbbatch.dbbatch.step;


import com.dbbatch.dbbatch.model.CrmInterfaceVO_Driv;
import com.dbbatch.dbbatch.model.CrmOdometer;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.data.MongoItemReader;
import org.springframework.batch.item.data.MongoItemWriter;
import org.springframework.batch.item.data.builder.MongoItemReaderBuilder;
import org.springframework.batch.item.data.builder.MongoItemWriterBuilder;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Map;

@Slf4j
@Component
@RequiredArgsConstructor
public class CrmDriveInfoMngrTask {


    @Autowired
    private MongoOperations mongoOperations;
    @Autowired
    @Qualifier("dataSource")
    private DataSource dataSource;

    @Value("${query.crm-drive-insert}")
    private String InsertQuery;

    @Bean
    public MongoItemReader<CrmOdometer> crmDriveReader(){
        log.info(">>>>>>>>>>>>>>>>>>> Drive CRM Reader Start");

        LocalDateTime localDateTime = LocalDateTime.now();

        //다음 날 새벽일 경우를 위해 toDate 도 minus 1일 할꺼임
        String fromDate = localDateTime.minusDays(1).getYear() + "/" + String.format("%02d",localDateTime.minusDays(1).getMonthValue()) + "/" + String.format("%02d",localDateTime.minusDays(1).getDayOfMonth()) + " 00:00:00";
        String toDate = localDateTime.minusDays(1).getYear() + "/" + String.format("%02d", localDateTime.minusDays(1).getMonthValue()) + "/" + String.format("%02d", localDateTime.minusDays(1).getDayOfMonth()) + " 23:59:59";

        Query query = new Query(Criteria.where("createDate").lte(toDate).gte(fromDate));


        return new MongoItemReaderBuilder<CrmOdometer>()
                .name("CrmsOdometer")
                .template(mongoOperations)
                .collection("CrmsOdometer")
                .targetType(CrmOdometer.class)
                .query(query)
                .sorts(Map.of("createDate", Sort.Direction.DESC))
                .pageSize(5000)
                .build();
    }


    @Bean
    public ItemProcessor<CrmOdometer, CrmInterfaceVO_Driv> crmDriveProcessor(){
        return crmOdometers ->{

            LocalDateTime now = LocalDateTime.now();
            LocalDateTime createDate = LocalDateTime.parse(crmOdometers.getCreateDate(), DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss"));
            Date date = java.sql.Timestamp.valueOf(createDate);

            return CrmInterfaceVO_Driv.builder()
                    .sysScnCd("L")
                    .eaiDate(now.format(DateTimeFormatter.ofPattern("yyyyMMdd")))
                    .eaiSeq(now.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) + (Math.round(Math.random() * 1000)))
                    .vin(crmOdometers.getVin())
                    .csmrMgmtNo("")
                    .trvgDist(crmOdometers.getOdometer())
                    .carRgstNo("")
                    .inpSysScnCd("L")
                    .ipeEeno("CRMEAI")
                    .inpDtm(date)
                    .altrSysScnCd("L")
                    .chgrEeno("CRMEAI")
                    .altrDtm(date)
                    .zifDate(null)
                    .zifrlt("Y")
                    .zifmsg("")
                    .sysReflDtm(null)
                    .sysReflYn("")
                    .nyaSbc("")
                    .build();
        };
    }

    @Bean
    public ItemWriter<CrmInterfaceVO_Driv> crmDriveWriter(){
        return CrmInterfaceVO_Driv -> {
            JdbcBatchItemWriter<CrmInterfaceVO_Driv> writer = new JdbcBatchItemWriterBuilder<CrmInterfaceVO_Driv>()
                    .dataSource(dataSource)
                    .sql(InsertQuery)
                    .beanMapped()
                    .build();

            writer.afterPropertiesSet();
            writer.write(CrmInterfaceVO_Driv);
        };
    }

    @Bean
    public MongoItemWriter<CrmInterfaceVO_Driv> crmDriveWriterSampling(){
        return new MongoItemWriterBuilder<CrmInterfaceVO_Driv>()
                .collection("CrmOdometerSampling")
                .template(mongoOperations)
                .build();
    }

}

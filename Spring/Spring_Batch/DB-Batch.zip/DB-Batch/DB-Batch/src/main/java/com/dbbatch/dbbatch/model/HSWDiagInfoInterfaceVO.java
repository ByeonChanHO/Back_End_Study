package com.dbbatch.dbbatch.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
public class HSWDiagInfoInterfaceVO {

    private String vin;

    private String creDtm;

    private String finMdfyDtm;

    private String dgnYmd;

    private String dgnCtms;


}

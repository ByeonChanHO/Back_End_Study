package com.dbbatch.dbbatch.model;

import lombok.*;
import org.springframework.data.mongodb.core.mapping.Document;

@Getter
@Setter
@Builder
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "CrmOdometer")
public class CrmOdometer {
    private String vin;
    private String createDate;
    private double odometer;


}

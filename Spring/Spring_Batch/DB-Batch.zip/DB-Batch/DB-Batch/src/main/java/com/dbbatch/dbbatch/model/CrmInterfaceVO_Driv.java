package com.dbbatch.dbbatch.model;

import lombok.*;

import java.util.Date;

@Getter
@Setter
@Builder
@ToString
public class CrmInterfaceVO_Driv {

    private String eaiDate;

    private String eaiSeq;

    private String sysScnCd;
    private String vin;

    private double trvgDist;

    private String csmrMgmtNo;

    private String carRgstNo;

    private String inpSysScnCd;

    private String ipeEeno;

    private Date inpDtm;

    private String altrSysScnCd;

    private String chgrEeno;

    private Date altrDtm;

    private String zifDate;

    private String zifrlt;
    private String zifmsg;
    private String sysReflDtm;
    private String sysReflYn;
    private String nyaSbc;






}

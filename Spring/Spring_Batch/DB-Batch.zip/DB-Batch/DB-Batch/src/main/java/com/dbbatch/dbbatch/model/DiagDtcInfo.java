package com.dbbatch.dbbatch.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString
@Builder
public class DiagDtcInfo {

    private UtcOffsetTime time;
    private DistanceType odometer;

    private List<BreakdownCode> codeList;


    @Getter
    @Setter
    @ToString
    @Builder
    private static class UtcOffsetTime {
        private String utc;
        private Integer offset;
    }

    @Getter
    @Setter
    @ToString
    @Builder
    private static class DistanceType {
        private Double value;
        private Integer unit;

    }

    @Getter
    @Setter
    @ToString
    @Builder
    private static class BreakdownCode {
        private String dtcCode;
        private String ecuID;

        private Integer milStatus;
    }
}

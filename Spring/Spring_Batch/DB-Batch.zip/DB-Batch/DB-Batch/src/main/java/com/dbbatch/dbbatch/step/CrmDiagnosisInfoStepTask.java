package com.dbbatch.dbbatch.step;


import com.dbbatch.dbbatch.model.CrmDiagInfo;
import com.dbbatch.dbbatch.model.CrmInterfaceVO;
import io.micrometer.common.util.StringUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.data.MongoItemReader;
import org.springframework.batch.item.data.MongoItemWriter;
import org.springframework.batch.item.data.builder.MongoItemReaderBuilder;
import org.springframework.batch.item.data.builder.MongoItemWriterBuilder;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Map;

@Slf4j
@RequiredArgsConstructor
@Component
public class CrmDiagnosisInfoStepTask {


    @Autowired
    @Qualifier("dataSource")
    private DataSource dataSource;

    @Value("${query.crm-if-insert}")
    private String ifInsertQuery;
    private final MongoOperations mongoOperations;

    @Bean
    public MongoItemReader<CrmDiagInfo> crmReader(){

        //다음날 새벽에 Batch 를 돌렸을 경우를 생각해서 -1일
        LocalDateTime localDateTime = LocalDateTime.now().minusDays(1);


        String fromDate = localDateTime.getYear() + "/" + String.format("%02d",localDateTime.getMonthValue()) + "/" + String.format("%02d",localDateTime.getDayOfMonth()) + " 00:00:00";
        String toDate = localDateTime.getYear() + "/" + String.format("%02d", localDateTime.getMonthValue()) + "/" + String.format("%02d", localDateTime.getDayOfMonth()) + " 23:59:59";

        Query query = new Query(new Criteria().andOperator(Criteria.where("createDate").lte(toDate).gte(fromDate), Criteria.where("dtcCalYn").is("")));


        return new MongoItemReaderBuilder<CrmDiagInfo>()
                .name("CrmsDiagInfo insert")
                .collection("CrmsDiagInfo")
                .template(mongoOperations)
                .targetType(CrmDiagInfo.class)
                .query(query)
                .sorts(Map.of("createDate", Sort.Direction.DESC))
                .pageSize(5000)
                .build();



    }

    @Bean
    public ItemProcessor<CrmDiagInfo, CrmInterfaceVO> crmProcess(){
        return crmDiagInfo ->{

            LocalDateTime createDate = LocalDateTime.parse(crmDiagInfo.getCreateDate(), DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss"));

            CrmInterfaceVO crmInterfaceVO = CrmInterfaceVO.builder()
                    .eaiDate(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd")))
                    .eaiSeq(LocalDateTime.now().format(DateTimeFormatter.ofPattern("HHmmss")) + (Math.round(Math.random() * 1000)))
                    .vin(crmDiagInfo.getVin())
                    .ecuIdNm(crmDiagInfo.getEcuIDName())
                    .bkdwNm(crmDiagInfo.getSystemName())
                    .occuYmd(createDate.format(DateTimeFormatter.ofPattern("yyyyMMdd")))
                    .occuCtms(createDate.format(DateTimeFormatter.ofPattern("HHmmss")))
                    .dtcCalYn(crmDiagInfo.getDtcCalYn())
                    .dtcCalDtm(crmDiagInfo.getDtcCalDate())
                    .sysNm(crmDiagInfo.getEcuIDName())
                    .build();

            //log.info("[CRM Processor] vin : {}, createDate : {}", crmInterfaceVO.getVin(), crmInterfaceVO.getEaiDate());

            return crmInterfaceVO;
        };
    }

    @Bean
    public ItemWriter<CrmInterfaceVO> crmWriter() {
        return crmInterfaceVO ->{
            JdbcBatchItemWriter<CrmInterfaceVO> writer = new JdbcBatchItemWriterBuilder<CrmInterfaceVO>()
                    .dataSource(dataSource)
                    .sql(ifInsertQuery)
                    .beanMapped()
                    .build();

            writer.afterPropertiesSet();
            writer.write(crmInterfaceVO);

            log.info("[CRM Writer First Data] vin : {}, createDate : {}", crmInterfaceVO.getItems().get(0).getVin(), crmInterfaceVO.getItems().get(0).getEaiDate());
        };
    }

    @Bean
    public MongoItemWriter<CrmInterfaceVO> crmWriterSampling(){
        return new MongoItemWriterBuilder<CrmInterfaceVO>()
                .collection("CrmDiagSampling")
                .template(mongoOperations)
                .build();
    }


}

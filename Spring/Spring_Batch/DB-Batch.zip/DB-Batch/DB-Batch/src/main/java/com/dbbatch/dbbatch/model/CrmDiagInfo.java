package com.dbbatch.dbbatch.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.mongodb.core.mapping.Document;

@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@Document(collection = "CrmsDiagInfo")
public class CrmDiagInfo {

    private String vin;
    private String dtcCodeName;
    private String systemName;
    private String ecuIDName;

    private String dtcCalYn;

    private String dtcCalDate;
    private String createDate;
}

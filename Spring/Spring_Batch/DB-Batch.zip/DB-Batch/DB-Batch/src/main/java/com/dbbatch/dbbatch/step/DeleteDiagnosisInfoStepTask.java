package com.dbbatch.dbbatch.step;

import com.dbbatch.dbbatch.model.DiagInfo;
import com.dbbatch.dbbatch.step.DeleteCustomItemReader.CustomMongoItemReader;
import com.dbbatch.dbbatch.step.DeleteCustomItemReader.CustomMongoItemReaderBuilder;
import com.mongodb.bulk.BulkWriteResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Component
@Slf4j
@RequiredArgsConstructor
public class DeleteDiagnosisInfoStepTask {

    private final MongoOperations mongoTemplate;

    public final String JSON_QUERY_FORMAT = "{createDate: {'$gte': '%s', '$lte': '%s'}}";

    public int totalCount = 0;

    public final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");


    @Bean
    @StepScope
    public CustomMongoItemReader<DiagInfo> CustomDelReader(@Value("#{jobParameters[checkTest]}") String checkTest) {
        log.info(">>>>>>>>>>>>>>> reader start");
        Query query = new Query();
        Criteria criteria = new Criteria();
        LocalDateTime nowTargetDate = LocalDateTime.now();


        if(checkTest.equals("true")) {
            log.info("Test gooooooooooood!!!!!!!!!!!!!!!!!!!");
            log.info("but i will force exception with u");
            throw new IllegalStateException( " TEST시간대로 인해 종료");


        }
        else {


            LocalDateTime targetDateTime = LocalDateTime.now().plusYears(100).minusDays(1);
            log.info("target Date Time : " + targetDateTime);

            String toyyyyMMdd = targetDateTime.getYear() + "/" + String.format("%02d", targetDateTime.getMonthValue()) + "/" + String.format("%02d", targetDateTime.getDayOfMonth()) + " 23:59:59";


            query.addCriteria(Criteria.where("createDate").lte(toyyyyMMdd)).with(Sort.by(Sort.Direction.ASC,"createDate"));

            log.info(mongoTemplate.findOne(query, DiagInfo.class, "Test001") + " ");
            nowTargetDate = LocalDateTime.parse(mongoTemplate.findOne(query, DiagInfo.class, "Test001").getCreateDate(), formatter);

            String fromyyyyMMdd = nowTargetDate.minusDays(1).getYear() + "/" + String.format("%02d",nowTargetDate.minusDays(1).getMonthValue()) + "/" + String.format("%02d",nowTargetDate.minusDays(1).getDayOfMonth()) + " 00:00:00";
            toyyyyMMdd = nowTargetDate.minusDays(1).getYear() + "/" + String.format("%02d", nowTargetDate.minusDays(1).getMonthValue()) + "/" + String.format("%02d", nowTargetDate.minusDays(1).getDayOfMonth()) + " 23:59:59";

            query = new Query();
            criteria.andOperator(Criteria.where("createDate").gte(fromyyyyMMdd), Criteria.where("createDate").lte(toyyyyMMdd));
            query.addCriteria(criteria);

            log.info("Revicing now Date: " + query);
        }




        return new CustomMongoItemReaderBuilder<DiagInfo>()
                .name("Delete Diag Info Data")
                .template(mongoTemplate)
                .collection("Test001")
                .targetType(DiagInfo.class)
                .query(query)
                .targetDate(nowTargetDate)
                .threadNum(20)
                .sorts(Map.of("createDate", Sort.Direction.ASC))
                .pageSize(50000)
                .build();


    }




    @Bean
    public ItemWriter<DiagInfo> delDiagInfoWriter(){

        return diagInfos ->{

//            LocalDateTime dateTime = LocalDateTime.now();
//            int hourMin = (dateTime.getHour()*100) + dateTime.getMinute();
//
//            if( (1650 <= hourMin && hourMin < 1900 )|| hourMin >= 2350 || (hourMin >= 650 && hourMin < 900) ){
//                throw new IllegalStateException(hourMin + " 시간대로 인해 종료");
//            }else{
//                bulkRemove(diagInfos);
//            }

            bulkRemove(diagInfos);

        };
    }




//    @Async
    public BulkWriteResult bulkRemove(Chunk<? extends DiagInfo> diagInfos) {
        log.info(">>>>>>>>>>>>>>>>> This is del Write Start");


        List<Query> removeList = new ArrayList<>();
        if(diagInfos.size() > 0) {
            log.info("Delete Driving Count : " + diagInfos.size());
            totalCount += diagInfos.size();
            log.info("totalCount : " + totalCount);

            log.info("createDate : {}", diagInfos.getItems().get(0).getCreateDate());


            for (DiagInfo delInfo : diagInfos) {
                Query query = new Query();
                Criteria first = Criteria.where("vin").is(delInfo.getVin());
                Criteria second = Criteria.where("createDate").is(delInfo.getCreateDate());
                query.addCriteria(new Criteria().andOperator(first, second));

                removeList.add(query);
            }
        }



        if(removeList.size() > 0){
            BulkOperations bulkOperations = mongoTemplate.bulkOps(BulkOperations.BulkMode.UNORDERED, DiagInfo.class);
            bulkOperations.remove(removeList);
            return bulkOperations.execute();
        }

        return null;
    }


}

package com.dbbatch.dbbatch.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.mapping.Document;

@Getter
@Setter
@ToString
@Document(collection = "Test001")
public class DiagInfo {


    private ObjectId _id;
    private String vin;
    private String nadid;
    private String createDate;

    private String bodyInfo;
}

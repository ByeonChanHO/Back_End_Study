package com.dbbatch.dbbatch.config;

import java.util.concurrent.ThreadFactory;

public class BachCustomThreadFactory implements ThreadFactory {

    private int ThreadCount;

    BachCustomThreadFactory(){
        ThreadCount = 0;
    }

    @Override
    public Thread newThread(Runnable r) {

        Thread thread = new Thread(r);
        thread.setName("CustomThread-" + ThreadCount);
        ThreadCount++;


        return thread;
    }
}

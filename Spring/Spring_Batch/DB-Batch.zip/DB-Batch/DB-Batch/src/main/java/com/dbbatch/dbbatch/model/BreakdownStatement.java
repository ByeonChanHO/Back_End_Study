package com.dbbatch.dbbatch.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.mongodb.core.mapping.Document;

@Getter
@Setter
@ToString
@Document(collection = "BreakdownStatement")
public class BreakdownStatement {


    private String ecuID;
    private String fuelType;
    private String ecuIDName;
    private String systemName;
    private String message;
    private String partLocCd;
    private String language;
    private String rgstDtm;

    private String rgstID;

}

package com.dbbatch.dbbatch.model;

public enum DiagUnitEnum {
    PREFIX("UNIT"),
    UNIT0("P0");

    public String unit;

    DiagUnitEnum(String unit) { this.unit = unit;}
}

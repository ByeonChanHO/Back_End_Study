package com.dbbatch.dbbatch.step.customItemReader;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import lombok.Builder;
import com.dbbatch.dbbatch.step.customItemReader.CustomMongoItemReader;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;



public class CustomMongoItemReaderBuilder<T> {

    private MongoOperations template;

    private String jsonQuery;

    private Class<? extends T> targetType;

    private Map<String, Sort.Direction> sorts;

    private String hint;

    private String fields;

    private String collection;

    private List<Object> parameterValues = new ArrayList<>();

    protected int pageSize = 10;

    private boolean saveState = true;

    private String name;

    private int maxItemCount = Integer.MAX_VALUE;

    private int currentItemCount;

    private Query query;


    public CustomMongoItemReaderBuilder<T> saveState(boolean saveState) {
        this.saveState = saveState;

        return this;
    }

    public CustomMongoItemReaderBuilder<T> name(String name) {
        this.name = name;

        return this;
    }


    public CustomMongoItemReaderBuilder<T> maxItemCount(int maxItemCount) {
        this.maxItemCount = maxItemCount;

        return this;
    }


    public CustomMongoItemReaderBuilder<T> currentItemCount(int currentItemCount) {
        this.currentItemCount = currentItemCount;

        return this;
    }

    public CustomMongoItemReaderBuilder<T> template(MongoOperations template) {
        this.template = template;

        return this;
    }


    public CustomMongoItemReaderBuilder<T> jsonQuery(String query) {
        this.jsonQuery = query;

        return this;
    }


    public CustomMongoItemReaderBuilder<T> targetType(Class<? extends T> targetType) {
        this.targetType = targetType;

        return this;
    }


    public CustomMongoItemReaderBuilder<T> parameterValues(List<Object> parameterValues) {
        this.parameterValues = parameterValues;

        return this;
    }


    public CustomMongoItemReaderBuilder<T> parameterValues(Object... parameterValues) {
        return parameterValues(Arrays.asList(parameterValues));
    }


    public CustomMongoItemReaderBuilder<T> fields(String fields) {
        this.fields = fields;

        return this;
    }

    public CustomMongoItemReaderBuilder<T> sorts(Map<String, Sort.Direction> sorts) {
        this.sorts = sorts;

        return this;
    }

    public CustomMongoItemReaderBuilder<T> collection(String collection) {
        this.collection = collection;

        return this;
    }


    public CustomMongoItemReaderBuilder<T> hint(String hint) {
        this.hint = hint;

        return this;
    }

    public CustomMongoItemReaderBuilder<T> pageSize(int pageSize) {
        this.pageSize = pageSize;

        return this;
    }

    public CustomMongoItemReaderBuilder<T> query(Query query) {
        this.query = query;

        return this;
    }


    public CustomMongoItemReader<T> build() {
        Assert.notNull(this.template, "template is required.");
        if (this.saveState) {
            Assert.hasText(this.name, "A name is required when saveState is set to true");
        }
        Assert.notNull(this.targetType, "targetType is required.");
        Assert.state(StringUtils.hasText(this.jsonQuery) || this.query != null, "A query is required");

        if (StringUtils.hasText(this.jsonQuery) || this.query != null) {
            Assert.notNull(this.sorts, "sorts map is required.");
        }

        CustomMongoItemReader<T> reader = new CustomMongoItemReader<>();
        reader.setTemplate(this.template);
        reader.setTargetType(this.targetType);
        reader.setQuery(this.jsonQuery);
        reader.setSort(this.sorts);
        reader.setHint(this.hint);
        reader.setFields(this.fields);
        reader.setCollection(this.collection);
        reader.setParameterValues(this.parameterValues);
        reader.setQuery(this.query);

        reader.setPageSize(this.pageSize);
        reader.setName(this.name);
        reader.setSaveState(this.saveState);
        reader.setCurrentItemCount(this.currentItemCount);
        reader.setMaxItemCount(this.maxItemCount);

        return reader;
    }

}

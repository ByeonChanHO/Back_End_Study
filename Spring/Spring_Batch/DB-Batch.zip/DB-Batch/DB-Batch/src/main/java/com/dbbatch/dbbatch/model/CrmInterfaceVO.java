package com.dbbatch.dbbatch.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
public class CrmInterfaceVO {

    private String eaiDate;

    private String eaiSeq;

    private String vin;

    private String ecuIdNm;

    private String bkdwNm;

    private String occuYmd;

    private String occuCtms;

    private String dtcCalYn;

    private String dtcCalDtm;

    private String sysNm;
}
